export const auditSchemaKey = 'x-pn-audit';
export const dataClassificationSchemaKey = 'dataClassification';